﻿using System;
using System.Collections.Generic;

#nullable disable

namespace pelajar.Models
{
    public partial class TbMahasiswa
    {
        public int Id { get; set; }
        public int IdJur { get; set; }
        public int IdKls { get; set; }
        public string Nama { get; set; }
    }
}
