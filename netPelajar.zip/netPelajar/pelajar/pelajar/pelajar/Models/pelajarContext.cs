﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace pelajar.Models
{
    public partial class pelajarContext : DbContext
    {
        public pelajarContext()
        {
        }

        public pelajarContext(DbContextOptions<pelajarContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TbJurusan> TbJurusans { get; set; }
        public virtual DbSet<TbKela> TbKelas { get; set; }
        public virtual DbSet<TbMahasiswa> TbMahasiswas { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=.;Database=pelajar;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<TbJurusan>(entity =>
            {
                entity.ToTable("tb_jurusan");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Jurusan)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("jurusan");
            });

            modelBuilder.Entity<TbKela>(entity =>
            {
                entity.ToTable("tb_kelas");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Kelas)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("kelas");
            });

            modelBuilder.Entity<TbMahasiswa>(entity =>
            {
                entity.ToTable("tb_mahasiswa");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.IdJur)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("id_jur");

                entity.Property(e => e.IdKls)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("id_kls");

                entity.Property(e => e.Nama)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("nama");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
