﻿using System;
using System.Collections.Generic;

#nullable disable

namespace pelajar.Models
{
    public partial class TbKela
    {
        public int Id { get; set; }
        public string Kelas { get; set; }
    }
}
