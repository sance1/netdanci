﻿using System;
using System.Collections.Generic;

#nullable disable

namespace pelajar.Models
{
    public partial class TbJurusan
    {
        public int Id { get; set; }
        public string Jurusan { get; set; }
    }
}
