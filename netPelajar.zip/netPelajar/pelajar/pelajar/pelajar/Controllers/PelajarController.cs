﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using pelajar.Models;

namespace pelajar.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PelajarController : ControllerBase
    {
        [Route("GetList")]
        [HttpGet]
        public IEnumerable<dynamic> GetList()
        {
            using var context = new pelajarContext();

            var query =
   from mahasiswa in context.TbMahasiswas
   join kelas in context.TbKelas on mahasiswa.IdKls equals (int?)kelas.Id
   select new { id = mahasiswa.Id, nama = mahasiswa.Nama, kelas = kelas.Kelas };

            return query.ToList();
        }

        [Route("TambahMahasiswa")]
        [HttpPost]
        public IEnumerable<TbMahasiswa> TambahMahasiswa(TbMahasiswa tblMahasiswa)
        {
            using var context = new pelajarContext();

            context.TbMahasiswas.Add(tblMahasiswa);

            context.SaveChanges();

            return context.TbMahasiswas.ToList();
        }

        [Route("TambahJurusan")]
        [HttpPost]
        public IEnumerable<TbJurusan> TambahJurusan(TbJurusan tbJurusan)
        {
            using var context = new pelajarContext();

            context.TbJurusans.Add(tbJurusan);

            context.SaveChanges();

            return context.TbJurusans.ToList();
        }

        [Route("TambahKelas")]
        [HttpPost]
        public IEnumerable<TbKela> TambahKelas(TbKela tbKela)
        {
            using var context = new pelajarContext();

            context.TbKelas.Add(tbKela);

            context.SaveChanges();

            return context.TbKelas.ToList();
        }

        [Route("HapusMahasiswa")]
        [HttpPost]
        public IEnumerable<TbMahasiswa> HapusMahasiswa(TbMahasiswa tbMahasiswaRequest)
        {
            using var context = new pelajarContext();

            TbMahasiswa tbMahasiswa = context.TbMahasiswas.Where(x => x.Id == tbMahasiswaRequest.Id).FirstOrDefault();
            context.TbMahasiswas.Remove(tbMahasiswa);

            context.SaveChanges();

            return context.TbMahasiswas.ToList();
        }

        [Route("UpdateMahasiswa")]
        [HttpPost]
        public IEnumerable<TbMahasiswa> UpdateMahasiswa(TbMahasiswa tbMahasiswaRequest)
        {
            using var context = new pelajarContext();
            TbMahasiswa mahasiswa = context.TbMahasiswas.Where(x => x.Id == tbMahasiswaRequest.Id).FirstOrDefault();
            mahasiswa.IdJur = tbMahasiswaRequest.IdJur;
            mahasiswa.IdKls = tbMahasiswaRequest.IdKls;
            mahasiswa.Nama = tbMahasiswaRequest.Nama;
            context.SaveChanges();

            return context.TbMahasiswas.ToList();
        }
    }
}
