<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="<?php echo base_url('assets/bootstrap-5.1.2-dist') ?>/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
    <style type="text/css">
    	.content{
    		margin-left: 20%;
    		margin-top: 50px;
    		width: 500px;
    		height: 500px;
    	}
    	h1{
    		margin-bottom: 50px;
    	}
    </style>
	<title>Update Data</title>
  </head>
  <body>
    <div class="content"><h1>Update Data</h1>
    
    <form method="post"  action="<?php echo site_url('Home/Edit_Proses/')?>">
    <?php foreach($Ambil_Tb_Mahasiswa as $tampil_B_id): ?>    
    <div class="form-group">
    	
            <label>Nama</label>
            <input type="hidden" name="id" class="form-control" value="<?php echo $tampil_B_id->id ?>">
            <input type="text" name="nama" class="form-control" value="<?php echo $tampil_B_id->nama ?>">
        </div>
        <div class="form-group">
            <label>Kelas</label>
            <select name='kelas' class="form-control">
                <?php foreach($Ambil_Kelas as $tampil_kls): ?> 
                <option value="<?php echo $tampil_kls->id ?>"><?php echo $tampil_kls->kelas ?></option>
                <?php endforeach ?>
            </select>     
        </div>
        <div class="form-group">
            <label>Jurusan</label>            
            <select name='jurusan' class="form-control">
                <?php foreach($Ambil_Jurusan as $tampil_jur): ?> 
                <option value="<?php echo $tampil_jur->id ?>"><?php echo $tampil_jur->jurusan ?></option>
                <?php endforeach ?>
            </select>          
        </div>

        <button type="button" class="btn btn-danger mt-3" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary mt-3">Simpan</button>

        <?php endforeach ?>

    </form>
	</div>
    
    <script src="<?php echo base_url('assets/bootstrap-5.1.2-dist') ?>//js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
  </body>
</html>