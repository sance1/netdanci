<!DOCTYPE html>

<html>
<head>
    <title>Test</title>
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
</head>
<body>
<div class="container" style="margin-top: 20px">
    <div class="row">
        <div class="col-md-12">
            <h2 style="text-align: center;margin-bottom: 30px">Data Mahasiswa</h2>
          <button type="button" class="btn btn-primary btn-lg btn-sm" data-toggle="modal" data-target="#myModal" style="margin-bottom: 20px;margin-left: 15px; ">
              Tambah Data
          </button>
              <?php echo $this->session->flashdata('pesan'); ?>  
            <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
              <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Posting</th>
               <th style="width:125px;">Action
                  </p></th>
                </tr>
              </thead>
              <tbody>
                    <?php 
                    $no=1;
                    foreach($Tampil_Data as $tampil):
                    ?>
                        <tr>
                            <td><?php echo $no++;?></td>
                            <td><?php echo $tampil->nama;?></td>
                            <td><?php echo $tampil->kelas;?></td>
                            <td><?php echo $tampil->jurusan;?></td>
                            <td style="text-align: center;">
                                <?php echo anchor('Home/Edit_Data/'.$tampil->id,'<button class="btn btn-sm btn-primary" onclick="edit_book(<?php echo $tampil->id;?>)"><i class="glyphicon glyphicon-pencil"></i></button>') ?>

                                <?php echo anchor('Home/Hapus_Data/'.$tampil->id,'<button class="btn btn-sm btn-danger" onclick="delete_book(<?php echo $tampil->id;?>)"><i class="glyphicon glyphicon-trash"></i></button>') ?>
                            </td>
                        </tr>
                    <?php endforeach?>

              </tbody>
            </table>
        </div>
    </div>
</div>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );
</script>



<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Tambah Data</h4>
      </div>

      <form method="post" action="<?php echo site_url('Home/Simpan_Data_Mahasiswa') ?>">
      <div class="modal-body">

        <div class="form-group">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control">
        </div>
        <div class="form-group">
            <label>Kelas</label>
            <select name='kelas' class="form-control">
                <?php foreach($Ambil_Kelas as $tampil_kls): ?> 
                <option value="<?php echo $tampil_kls->id ?>"><?php echo $tampil_kls->kelas ?></option>
                <?php endforeach ?>
            </select>     
        </div>
        <div class="form-group">
            <label>Jurusan</label>            
            <select name='jurusan' class="form-control">
                <?php foreach($Ambil_Jurusan as $tampil_jur): ?> 
                <option value="<?php echo $tampil_jur->id ?>"><?php echo $tampil_jur->jurusan ?></option>
                <?php endforeach ?>
            </select>          
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
      </form>

    </div>
  </div>
</div>

</body>
</html>