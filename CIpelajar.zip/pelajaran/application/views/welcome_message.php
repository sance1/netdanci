<?php
$serverName="SANCE-PC";
$conn=new PDO("sqlsrv:server=$serverName;Database=pelajar");
if($conn){
echo "Connect </br>";
}else{
echo "gagal";
die(print_r(sqlsrv_errors(),true));
}
$sql='select * from tb_mahasiswa';
foreach($conn->query($sql)as $row){
 print $row['Nama'] ."\t";
 print $row['alamat']."\t";
 print $row['nim']."</br>";
}
?>