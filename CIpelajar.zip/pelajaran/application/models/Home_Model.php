<?php  
class Home_Model extends CI_Model{
	public function Tampil_Data()
	{
		$result = $this->db->query("Select MHS.id,MHS.nama,KLS.kelas,JUR.jurusan
					from tb_mahasiswa MHS
					Left Join tb_kelas KLS On KLS.id=MHS.id_kls
					Left Join tb_jurusan JUR on JUR.id=MHS.id_jur order by id desc");
		return $result;
	}

	public function Ambil_Kelas()
	{
		$result = $this->db->query("select * from tb_kelas");
		return $result;
	}

	public function Ambil_Tb_Mahasiswa($id)
	{
		$result = $this->db->select('*')
						   ->where('id',$id)
						   ->get('tb_mahasiswa');
		return $result;
	}

	public function Edit_Proses($table,$data,$where)
	{
		$this->db->where($where);
		$this->db->update($table,$data);
	}
}
?>