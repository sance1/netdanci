<?php  
class Home extends CI_Controller{

	public function index()
	{
		$data['Tampil_Data'] = $this->Home_Model->Tampil_Data()->result();
		$data['Ambil_Kelas'] = $this->Home_Model->Ambil_kelas()->result();
		$data['Ambil_Jurusan'] = $this->db->query('select * from tb_jurusan')->result();
		$this->load->view('Home',$data);
	}

	public function Simpan_Data_Mahasiswa()
	{
		$nama 		= $this->input->post('nama');
		$kelas		= $this->input->post('kelas');
		$jurusan	= $this->input->post('jurusan');

		$data_mhs = array(
			'id_jur' => $jurusan,
			'id_kls' => $kelas,
			'nama' 	 => $nama
		);
		$this->db->insert('tb_mahasiswa',$data_mhs);
		redirect("Home/Simpan_Sukses");
	}
	public function Simpan_Sukses()
	{
		$data['Tampil_Data'] = $this->Home_Model->Tampil_Data()->result();
		$data['Ambil_Kelas'] = $this->Home_Model->Ambil_kelas()->result();
		$data['Ambil_Jurusan'] = $this->db->query('select * from tb_jurusan')->result();
		$this->load->view('Home',$data);
	}

	public function Edit_Data($id)
	{
		$data['Ambil_Kelas'] = $this->Home_Model->Ambil_kelas()->result();
		$data['Ambil_Jurusan'] = $this->db->query('select * from tb_jurusan')->result();
		$data['Ambil_Tb_Mahasiswa']	= $this->Home_Model->Ambil_Tb_Mahasiswa($id)->result();
		$this->load->view("Edit_Data",$data);
	}

	public function Edit_Proses()
	{

		$id 		= $this->input->post('id');
		$nama 		= $this->input->post('nama');
		$kelas 	 	= $this->input->post('kelas');
		$jurusan 	= $this->input->post('jurusan');


		$where = array('id' => $id);
		$data  = array(
			'nama'   => $nama,
			'id_kls' => $kelas,
			'id_jur' => $jurusan
		);
		$this->Home_Model->Edit_Proses('tb_mahasiswa',$data,$where);
		redirect('Home/index');
	}

	public function	Hapus_Data($id)
	{
		$this->db->query("Delete From tb_mahasiswa	where id='$id'");
		$this->session->set_flashdata('pesan',"<div class='alert alert-danger alert-dismissible' role='alert'>
			  <button type='button' class='close btn-sm' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
	  		<strong>Berhasil ...! </strong> Data Berhasil Dihapus
			</div>");
			redirect('Home/index');
	}
}
?>